-- --------  << AULA 4 Exercicio 5 Evolucaoo 4 >>  ----------
--
--                    SCRIPT DE POPULAR (DML)
--
-- Data Criacao ...........: 01/03/2022
-- Autor(es) ..............: Pedro Henrique Carvalho Campos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao4
--
-- Ultimas Alteracoes
--   01/03/2022 => criação do script
--	
-- 	
-----------------------------------------------------------
use aula4exer5Evolucao4;

INSERT INTO MEDICO(crmNumero, nomeCompleto,crmEstado) VALUES('3711', 'Walmir Alencar', 'DF');
INSERT INTO MEDICO(crmNumero, nomeCompleto,crmEstado) VALUES('3877', 'Alessandro Barbosa', 'DF');
INSERT INTO MEDICO(crmNumero, nomeCompleto,crmEstado) VALUES('3971', 'José Carneiro', 'DF');

INSERT INTO ESPECIALIDADE(tipoEspecialidade, codigoEspecialidade) VALUES('Neonatologia', '1');
INSERT INTO ESPECIALIDADE(tipoEspecialidade, codigoEspecialidade) VALUES('Dermatologia', '2');
INSERT INTO ESPECIALIDADE(tipoEspecialidade, codigoEspecialidade) VALUES('Neurologia', '3');

INSERT INTO possui(crmNumero, crmEstado, codigoEspecialidade) VALUES('3711', 'DF', '1');
INSERT INTO possui(crmNumero, crmEstado, codigoEspecialidade) VALUES('3971', 'DF', '2');
INSERT INTO possui(crmNumero, crmEstado, codigoEspecialidade) VALUES('3877', 'DF', '3');

INSERT INTO PACIENTE(nomeCompleto, sexo, cep, rua, bairro, numero, cidade,
estado, complemento, idPaciente,dataNascimneto) VALUES('Pedro Georgioneo',
'M', '7236498','quadra 400','Samambaia','18','Brasilia', 'DF','','1','2000/05/09');
INSERT INTO PACIENTE(nomeCompleto, sexo, cep, rua, bairro, numero, cidade,
estado, complemento, idPaciente,dataNascimneto) VALUES('Mario Andrade',
'M', '7239855','quadra 409','Taguatinga','29','Brasilia', 'DF','Apartamento 16','2','1996/08/10');
INSERT INTO PACIENTE(nomeCompleto, sexo, cep, rua, bairro, numero, cidade,
estado, complemento, idPaciente,dataNascimneto) VALUES('Ana Almeida',
'F', '7240198','quadra 300','Gama','20','Brasilia', 'DF','','3','1982/03/22');

INSERT INTO telefone(idPaciente,telefone) VALUES('1','61999133333');
INSERT INTO telefone(idPaciente,telefone) VALUES('2','61981235634');
INSERT INTO telefone(idPaciente,telefone) VALUES('3','61987358965');
INSERT INTO telefone(idPaciente,telefone) VALUES('3','6133335689');

INSERT INTO CONSULTA(dataConsulta,horario,crmNumero,idPaciente,crmEstado,
idConsulta) VALUES('2022/02/27','10:41:00','3711','1','DF','1');
INSERT INTO CONSULTA(dataConsulta,horario,crmNumero,idPaciente,crmEstado,
idConsulta) VALUES('2022/02/27','13:00:00','3711','2','DF','2');
INSERT INTO CONSULTA(dataConsulta,horario,crmNumero,idPaciente,crmEstado,
idConsulta) VALUES('2022/02/27','15:00:00','3971','3','DF','3');

INSERT INTO RECEITA(dataEmissao,idReceita) VALUES('2022/02/27','1');
INSERT INTO RECEITA(dataEmissao,idReceita) VALUES('2022/02/27','2');
INSERT INTO RECEITA(dataEmissao,idReceita) VALUES('2022/02/27','3');

INSERT INTO MEDICAMENTO(idReceita,medicamento) VALUES('1','Abacavir'); 
INSERT INTO MEDICAMENTO(idReceita,medicamento) VALUES('2','Abaloparatida');
INSERT INTO MEDICAMENTO(idReceita,medicamento) VALUES('3','Abciximabe');



