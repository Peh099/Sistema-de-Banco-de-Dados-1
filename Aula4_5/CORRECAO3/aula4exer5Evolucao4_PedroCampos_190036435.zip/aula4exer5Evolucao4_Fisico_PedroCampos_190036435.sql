-- --------  << AULA 4 Exercicio 5 Evolucaoo 4 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 01/03/2022
-- Autor(es) ..............: Pedro Henrique Carvalho Campos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao4
--
-- Ultimas Alteracoes
--   01/03/2022 => criação do script
--	
-- 	
-----------------------------------------------------------

create database
	IF NOT EXISTS aula4exer5Evolucao4;
    
use aula4exer5Evolucao4;

CREATE TABLE MEDICO (
    crmNumero INT NOT NULL,
    nomeCompleto VARCHAR(50) NOT NULL,
    crmEstado CHAR(2) NOT NULL,
    PRIMARY KEY (crmNumero, crmEstado)
);

CREATE TABLE PACIENTE (
    nomeCompleto VARCHAR(50) NOT NULL,
    sexo CHAR(1) NOT NULL,
    cep INT NOT NULL,
    rua VARCHAR(50) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    numero INT NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    estado VARCHAR(50) NOT NULL,
    complemento VARCHAR(50),
    idPaciente INT NOT NULL PRIMARY KEY,
    dataNascimneto DATE NOT NULL
);

CREATE TABLE CONSULTA (
    dataConsulta DATE NOT NULL,
    horario TIME NOT NULL,
    crmNumero INT NOT NULL,
    idPaciente INT NOT NULL,
    crmEstado CHAR(2) NOT NULL,
    idConsulta INT NOT NULL PRIMARY KEY,
    constraint CONSULTA_MEDICO_FK foreign key (crmNumero,crmEstado)
	references MEDICO (crmNumero,crmEstado),
    constraint CONSULTA_PACIENTE_FK foreign key (idPaciente)
	references PACIENTE (idPaciente)
);

CREATE TABLE RECEITA (
    dataEmissao DATE NOT NULL,
    idReceita INT NOT NULL PRIMARY KEY
);

CREATE TABLE ESPECIALIDADE (
    tipoEspecialidade VARCHAR(50) NOT NULL,
    codigoEspecialidade INT NOT NULL PRIMARY KEY
);

CREATE TABLE medicamento (
    idReceita INT NOT NULL,
    medicamento VARCHAR(50) NOT NULL,
    constraint medicamento_RECEITA_FK foreign key (idReceita)
	references RECEITA (idReceita)
);

CREATE TABLE possui (
    crmNumero INT NOT NULL,
    crmEstado CHAR(2) NOT NULL,
    codigoEspecialidade INT NOT NULL,
    constraint possui_MEDICO_FK foreign key (crmNumero,crmEstado)
	references MEDICO (crmNumero,crmEstado),
	constraint possui_ESPECIALIDADE_FK foreign key (codigoEspecialidade)
	references ESPECIALIDADE (codigoEspecialidade)
);

CREATE TABLE telefone (
    idPaciente INT NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    constraint telefone_PACIENTE_FK foreign key (idPaciente)
	references PACIENTE (idPaciente)
);


