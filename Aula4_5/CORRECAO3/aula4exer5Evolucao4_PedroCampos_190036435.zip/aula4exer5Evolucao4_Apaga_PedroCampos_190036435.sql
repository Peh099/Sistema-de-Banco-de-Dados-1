-- --------  << AULA 4 Exercicio 5 Evolucaoo 4 >>  ----------
--
--                    SCRIPT DE DELETAR (DDL)
--
-- Data Criacao ...........: 01/03/2022
-- Autor(es) ..............: Pedro Henrique Carvalho Campos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao4
--
-- Ultimas Alteracoes
--   01/03/2022 => criação do script
--	
-- 	
-----------------------------------------------------------

SET foreign_key_checks=off;

use aula4exer5Evolucao4;

DROP TABLE IF EXISTS MEDICO;
DROP TABLE IF EXISTS PACIENTE;
DROP TABLE IF EXISTS CONSULTA;
DROP TABLE IF EXISTS RECEITA;
DROP TABLE IF EXISTS ESPECIALIDADE;
DROP TABLE IF EXISTS possui;
DROP TABLE IF EXISTS medicamento;
DROP TABLE IF EXISTS telefone;

SET foreign_key_checks=on;