-- --------  << aula9extra1 >>  -------------------------
--
--            SCRIPT APAGA (DDL)
--
-- Data Criacao ...........: 30/03/2022
-- Autor(es) ..............: Pedro Henrique Carvalho Campos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula9extra1
--
--
-- Ultimas Alteracoes
--
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
--
-- ----------------------------------------------------------

use aula9extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;
