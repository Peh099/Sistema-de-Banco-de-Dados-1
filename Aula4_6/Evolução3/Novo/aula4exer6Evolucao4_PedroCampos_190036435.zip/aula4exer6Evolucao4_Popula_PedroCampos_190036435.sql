-- --------- << aula4exer6Evolucao4 >> ---------
-- 
--           SCRIPT POPULA (DML)
--
-- Data Criacao ......: 27/02/2022
-- Autor(es) .........: Lucas da Cunha Andrade, Victor Eduardo Araujo Ribeiro, Pedro Henrique Carvalho Campos
-- Banco de Dados ....: MySQL 8.0
-- Base de Dados .....: aula4exer6Evolucao4
--
-- Ultimas Alteracoes
--   Victor Eduardo: 09/03/2022  => Inserindo 3 tuplas a mais em cada tabela (totalizando 6)
-- 					             => Alterando a ordem das tabelas, deixando na mesma ordem do script de criacao
--   Pedro Campos: 18/03/2022    => Mudança no nome da base de dados
--                       
-- PROJETO => 01 Base de Dados
-- 		   => 11 Tabelas
--         => 2 perfis
--         => 4 consultas
--

INSERT INTO PROPRIETARIO VALUES ('12345678900', 'Pablo Escobar Costa', 'M', '1996-06-01', 'Limoes', '98625471', 'Pedrinhas', 12, 'Santo Andre', 'SP',null);
INSERT INTO PROPRIETARIO VALUES ('47312343520', 'Nicolas Cauã Melo', 'M', '1957-02-19', 'Estrada do Francês', '96222158', 'Quinta', 673, 'Rio Grande', 'RS',null);
INSERT INTO PROPRIETARIO VALUES ('54639586965', 'Brenda Maya Rezende', 'F', '1997-01-06', 'Rua Valdemiro Ender', '89208718', 'Petrópolis', 364, 'Joinville', 'SC', 'Esquina em frente a igreja');
INSERT INTO PROPRIETARIO VALUES ('00987654321', 'Bryan Manuel Rafael Bernardes', 'M', '1942-03-08', 'Beco São Francisco', '69027352', 'São Raimundo', 573, 'Manaus', 'AM',null);
INSERT INTO PROPRIETARIO VALUES ('76069851030', 'Luisa Valerio de Franca', 'F', '2001-05-09', 'Jardins', '65897852', 'Asa Sul', 16, 'Brasilia', 'DF',null) ;
INSERT INTO PROPRIETARIO VALUES ('15975365485', 'Gustavo da Silva', 'M', '1952-10-07', 'Bernardo', '25878965', 'Agostinho', 25, 'Rio de Janeiro', 'RJ', 'Ao lado da padaria');

INSERT INTO MODELO(nome) VALUES('Scania R440');
INSERT INTO MODELO(nome) VALUES('Honda PCX 150');
INSERT INTO MODELO(nome) VALUES('Toyota Hilux SW4');
INSERT INTO MODELO(nome) VALUES('Volvo FH 540');
INSERT INTO MODELO(nome) VALUES('Yamaha MT-09');
INSERT INTO MODELO(nome) VALUES('GOL 1.8');

INSERT INTO CATEGORIA(nome) VALUES ('Motocicleta');
INSERT INTO CATEGORIA(nome) VALUES ('Caminhão');
INSERT INTO CATEGORIA(nome) VALUES ('Automóvel');
INSERT INTO CATEGORIA(nome) VALUES ('Camioneta');
INSERT INTO CATEGORIA(nome) VALUES ('Caminhão Trator');
INSERT INTO CATEGORIA(nome) VALUES ('Outros');

INSERT INTO VEICULO VALUES('QGZ6534', '8BRBLWHEXAX22256', 'Preta', 2015, '12345678900', 1, 1);
INSERT INTO VEICULO VALUES('2589631', '2AAAD3SEF67EA504', 'Preta', 2021, '47312343520', 2, 2);
INSERT INTO VEICULO VALUES('F5K2X50', '669CUARXUMGAA191', 'Azul', 2018, '54639586965', 3, 3);
INSERT INTO VEICULO VALUES('JVG5954', '1BRBLWHEXAX24234', 'Prata', 2019, '00987654321', 4, 4);
INSERT INTO VEICULO VALUES('8E9NV37', '6RULSXT2EW2CM523', 'Preta', 2017, '76069851030', 5, 5);
INSERT INTO VEICULO VALUES('2547893', '5RUXXWGFXAX31316', 'Preto', 2011, '15975365485', 6, 6);

INSERT INTO AGENTE VALUES('369852', 'Carlos Emanuel da Costa', '2015-05-22');
INSERT INTO AGENTE VALUES('211921', 'Luis Verissimo', '2012-01-06');
INSERT INTO AGENTE VALUES('101941', 'Rafael Lima Jorge Nascimento', '2018-02-15');
INSERT INTO AGENTE VALUES('516165', 'Rafael Gustavo Ribeiro', '2016-03-16');
INSERT INTO AGENTE VALUES('165876', 'Renato da Silva Pereira', '2019-04-17');
INSERT INTO AGENTE VALUES('015058', 'Antonio Costa de Jesus', '2018-05-17');

INSERT INTO LOCALIZACAO(latitude, longitude) VALUES(258.36, 98.25);
INSERT INTO LOCALIZACAO(latitude, longitude) VALUES(113.25, 102.58);
INSERT INTO LOCALIZACAO(latitude, longitude) VALUES(113.25, 102.58);
INSERT INTO LOCALIZACAO(latitude, longitude) VALUES(113.25, 102.58);
INSERT INTO LOCALIZACAO(latitude, longitude) VALUES(113.25, 102.58);
INSERT INTO LOCALIZACAO(latitude, longitude) VALUES(52.12, 85.12);

INSERT INTO TIPO(nome, valor) VALUES('AVANCO SINAL', 167);
INSERT INTO TIPO(nome, valor) VALUES('BUZINAR EM DESACORDO COM AS NORMAS', 189);
INSERT INTO TIPO(nome, valor) VALUES('FICAR SEM COMBUSTÍVEL EM VIA PÚBLICA', 195);
INSERT INTO TIPO(nome, valor) VALUES('TRAFEGAR SEM USAR O CINTO DE SEGURANÇA', 300);
INSERT INTO TIPO(nome, valor) VALUES('VELOCIDADE EXCEDIDA', 195);
INSERT INTO TIPO(nome, valor) VALUES('ESTACIONAR O VEÍCULO EM VIADUTOS, PONTES OU TÚNEIS', 266);

INSERT INTO INFRACAO(dataOcorrencia, hora, velocidadeRegistrada, placa,  codigoTipo) VALUES('2021-12-03', '12:31:09', 74, 'QGZ6534',1);
INSERT INTO INFRACAO(dataOcorrencia, hora, velocidadeRegistrada, placa, codigoTipo) VALUES('2021-12-25', '10:30:36', NULL, '2589631', 2);
INSERT INTO INFRACAO(dataOcorrencia, hora, velocidadeRegistrada, placa,  codigoTipo) VALUES('2022-01-25', '13:30:56', NULL, 'F5K2X50', 3);
INSERT INTO INFRACAO(dataOcorrencia, hora, velocidadeRegistrada, placa, codigoTipo) VALUES('2021-09-30', '01:55:36', NULL, 'JVG5954', 4);
INSERT INTO INFRACAO(dataOcorrencia, hora, velocidadeRegistrada, placa,  codigoTipo) VALUES('2021-05-31', '15:55:36', NULL, '8E9NV37', 5);
INSERT INTO INFRACAO(dataOcorrencia, hora, velocidadeRegistrada, placa, codigoTipo) VALUES('2021-09-24', '19:25:12', 255, '2547893', 6);

INSERT INTO telefone(cpf, telefone) VALUES ('12345678900', '11932198391');
INSERT INTO telefone(cpf, telefone) VALUES ('47312343520', '2113921838');
INSERT INTO telefone(cpf, telefone) VALUES ('54639586965', '8220066159');
INSERT INTO telefone(cpf, telefone) VALUES ('00987654321', '89935794241');
INSERT INTO telefone(cpf, telefone) VALUES ('76069851030', '61999692547');
INSERT INTO telefone(cpf, telefone) VALUES ('15975365485', '7495231366');

INSERT INTO situa(idLocal,idInfracao) VALUES(1,1);
INSERT INTO situa(idLocal,idInfracao) VALUES(2,2);
INSERT INTO situa(idLocal,idInfracao) VALUES(3,3);
INSERT INTO situa(idLocal,idInfracao) VALUES(4,4);
INSERT INTO situa(idLocal,idInfracao) VALUES(5,5);
INSERT INTO situa(idLocal,idInfracao) VALUES(6,6);

INSERT INTO aplica(matricula,idInfracao) VALUES(369852,1);
INSERT INTO aplica(matricula,idInfracao) VALUES(211921,2);
INSERT INTO aplica(matricula,idInfracao) VALUES(101941,3);
INSERT INTO aplica(matricula,idInfracao) VALUES(516165,4);
INSERT INTO aplica(matricula,idInfracao) VALUES(165876,5);
INSERT INTO aplica(matricula,idInfracao) VALUES(015058,6);
