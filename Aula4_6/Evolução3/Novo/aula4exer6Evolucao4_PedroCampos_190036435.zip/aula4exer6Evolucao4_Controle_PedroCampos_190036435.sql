-- --------  << aula4exer6Evolucao4 >>  ----------
--
--          SCRIPT DE CONTROLE (DDL)
-- Data Criacao ......: 18/04/2022
-- Autor(es) .........: Pedro Henrique Carvalho Campos
-- Banco de Dados ....: MySQL 8.0
-- Base de Dados .....: aula4exer6Evolucao4
--
-- Ultimas Alteracoes
--
-- PROJETO => 01 Base de Dados
-- 		   => 11 Tabelas
--         => 2 perfis
--         => 4 consultas
-- 	--

-- USUARIO
CREATE USER admin
IDENTIFIED BY 'adm2022';

CREATE USER pessoa
IDENTIFIED BY '2pess2';

-- PERMISSAO
GRANT ALL PRIVILEGES ON aula4exer6Evolucao4.* TO admin;
GRANT INSERT ON aula4exer6Evolucao4.PROPRIETARIO TO pessoa;
GRANT INSERT ON aula4exer6Evolucao4.VEICULO TO pessoa;

