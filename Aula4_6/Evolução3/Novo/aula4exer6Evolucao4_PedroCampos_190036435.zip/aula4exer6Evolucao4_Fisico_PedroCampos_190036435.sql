-- --------- << aula4exer6Evolucao4 >> ---------
-- 
--           SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ......: 27/02/2022
-- Autor(es) .........: Lucas da Cunha Andrade, Victor Eduardo Araujo Ribeiro, Pedro Henrique Carvalho Campos
-- Banco de Dados ....: MySQL 8.0
-- Base de Dados .....: aula4exer6Evolucao4
--
-- Ultimas Alteracoes
--   Victor Eduardo: 09/03/2022 => Alteracao na tabela MODELO retirando codigoCategoria.
-- 								=> Alteracao na tabela MODELO inserindo a restricao MODELO_PK.
-- 								=> Alteracao na tabela MODELO inserindo valor inicial 10000 para o AUTO_INCREMENT.
-- 								=> Alteracao na tabela VEICULO inserindo codigoCategoria.
-- 								=> Alteracao na tabela VEICULO inserindo as restricoes: VEICULO_PK, VEICULO_UK, VEICULO_PROPRIETARIO_FK, VEICULO_MODELO_FK, VEICULO_CATEGORIA_FK.
--              				=> Alteracao na tabela LOCALIZACAO retirando nome.
--  							=> Alteracao na tabela PROPRIETARIO inserindo a restricao PROPRIETARIO_PK.
-- 								=> Alteracao na tabela AGENTE inserindo a restricao AGENTE_PK.
-- 								=> Alteracao na tabela CATEGORIA inserindo a restricao CATEGORIA_PK.
-- 								=> Alteracao na tabela CATEGORIA inserindo valor inicial 10 para o AUTO_INCREMENT.
-- 								=> Alteracao na tabela INFRACAO_PK inserindo as restricoes INFRACAO_PK, INFRACAO_VEICULO_FK, INFRACAO_LOCALIZACAO_FK, INFRACAO_TIPO_FK, INFRACAO_AGENTE_FK.
-- 								=> Alteracao na tabela LOCALIZACAO inserindo a restricao LOCALIZACAO_PK.
-- 								=> Alteracao na tabela TIPO inserindo a restricao TIPO_PK.
-- 								=> Alteracao na tabela telefone inserindo a restricao telefone_UK.
-- 								=> Alteracao em todas as tabelas inserindo Engine.
-- 								=> Alteracao na ordem das tabelas para que seja possivel a criacao dessas.
-- 								=> Alteracao na obrigatoriedade dos atributos para que seja coerente com modelo conceitual do projeto.
--
--   Pedro Campos:  18/04/2022  => Adicao On delete e on update nas tabelas
--                              => Mudança no relacionamento e adição tabelas de relacionamento n:m = aplica e situa
--                              => Mudança no nome da base de dados
--
-- PROJETO => 01 Base de Dados
-- 		   => 11 Tabelas
--         => 2 perfis
--         => 4 consultas
-- -------------------------------
create database
	IF NOT EXISTS aula4exer6Evolucao4;

USE aula4exer6Evolucao4;

CREATE TABLE PROPRIETARIO (
    cpf BIGINT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    sexo VARCHAR(9) NOT NULL,
    dataNascimento DATE NOT NULL,
    rua VARCHAR(50) NOT NULL,
    cep BIGINT NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    numero INT NOT NULL,
    cidade VARCHAR(30) NOT NULL,
    estado CHAR(2) NOT NULL,
    complemento VARCHAR(50),
    CONSTRAINT PROPRIETARIO_PK PRIMARY KEY (cpf)
)ENGINE=InnoDB;

CREATE TABLE MODELO (
    idModelo INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
	CONSTRAINT MODELO_PK PRIMARY KEY (idModelo)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE CATEGORIA (
    codigoCategoria INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    CONSTRAINT CATEGORIA_PK PRIMARY KEY (codigoCategoria)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE VEICULO (
    placa CHAR(7) NOT NULL,
    chassi CHAR(16) NOT NULL,
    cor VARCHAR(20) NOT NULL,
    anoFabricacao INT NOT NULL,
    cpf BIGINT NOT NULL,
    idModelo INT NOT NULL,
    codigoCategoria INT NOT NULL,
    CONSTRAINT VEICULO_PK PRIMARY KEY (placa),
    CONSTRAINT VEICULO_UK UNIQUE (chassi),
    CONSTRAINT VEICULO_PROPRIETARIO_FK FOREIGN KEY (cpf) REFERENCES PROPRIETARIO (cpf)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT VEICULO_MODELO_FK FOREIGN KEY (idModelo) REFERENCES MODELO (idModelo)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT VEICULO_CATEGORIA_FK FOREIGN KEY (codigoCategoria) REFERENCES CATEGORIA (codigoCategoria)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
)ENGINE=InnoDB ;

CREATE TABLE AGENTE (
    matricula INT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    dataContratacao DATE NOT NULL,
    CONSTRAINT AGENTE_PK PRIMARY KEY (matricula)
)ENGINE=InnoDB;

CREATE TABLE TIPO (
    codigoTipo INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    valor DECIMAL(6,2) NOT NULL,
    CONSTRAINT TIPO_PK PRIMARY KEY (codigoTipo)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE INFRACAO (
    idInfracao INT NOT NULL AUTO_INCREMENT,
    dataOcorrencia DATE NOT NULL,
    hora TIME NOT NULL,
    velocidadeRegistrada DECIMAL(5,2),
    placa CHAR(7) NOT NULL,
    codigoTipo INT NOT NULL,
    CONSTRAINT INFRACAO_PK PRIMARY KEY (idInfracao),
    CONSTRAINT INFRACAO_VEICULO_FK FOREIGN KEY (placa) REFERENCES VEICULO (placa)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT INFRACAO_TIPO_FK FOREIGN KEY (codigoTipo) REFERENCES TIPO (codigoTipo)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE LOCALIZACAO (
    idLocal INT NOT NULL AUTO_INCREMENT,
    latitude VARCHAR(15) NOT NULL,
    longitude VARCHAR(15) NOT NULL,
    velocidadePermitida DECIMAL(5,2),
    CONSTRAINT LOCALIZACAO_PK PRIMARY KEY (idLocal)
)ENGINE=InnoDB AUTO_INCREMENT=1;


CREATE TABLE telefone (
    cpf BIGINT NOT NULL,
    telefone BIGINT NOT NULL,
    CONSTRAINT telefone_UK UNIQUE (cpf,telefone),
    CONSTRAINT telefone_PROPRIETARIO_FK FOREIGN KEY (cpf) REFERENCES PROPRIETARIO (cpf)
		ON DELETE CASCADE
		ON UPDATE CASCADE
)ENGINE=InnoDB;

CREATE TABLE aplica (
    matricula INT NOT NULL,
    idInfracao INT NOT NULL,
    CONSTRAINT aplica_AGENTE_FK FOREIGN KEY (matricula) REFERENCES AGENTE (matricula)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
    CONSTRAINT aplica_INFRACAO_FK FOREIGN KEY (idInfracao) REFERENCES INFRACAO (idInfracao)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT    
)ENGINE=InnoDB;

CREATE TABLE situa (
    idLocal INT NOT NULL,
    idInfracao INT NOT NULL,
    CONSTRAINT situa_LOCAL_FK FOREIGN KEY (idLocal) REFERENCES LOCALIZACAO (idLocal)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT,
	CONSTRAINT situa_INFRACAO_FK FOREIGN KEY (idInfracao) REFERENCES INFRACAO (idInfracao)
		ON DELETE RESTRICT
		ON UPDATE RESTRICT
)ENGINE=InnoDB ;

