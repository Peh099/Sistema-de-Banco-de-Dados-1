-- --------  << aula4exer6Evolucao4 >>  ----------
--
--          SCRIPT DE CONSULTA  (DML)
-- Data Criacao ......: 18/04/2022
-- Autor(es) .........: Pedro Henrique Carvalho Campos
-- Banco de Dados ....: MySQL 8.0
-- Base de Dados .....: aula4exer6Evolucao4
--
-- Ultimas Alteracoes
--
-- PROJETO => 01 Base de Dados
-- 		   => 11 Tabelas
--         => 2 perfis
--         => 4 consultas
-- 	--
USE aula4exer6Evolucao4;

-- Demanda A)
-- Apresentar todos os dados dos veículos de um determinado proprietário fornecido pelo usuário,
-- relacionando por extenso a categoria que cada um é classificado (em VIEW) ;
CREATE VIEW DADOSVEICULO (
		placa,chassi,cor,anoFabricacao,cpf,idModelo,codigoCategoria,nome) AS
SELECT v.*,c.nome
  FROM VEICULO v JOIN CATEGORIA c ON v.codigoCategoria = c.codigoCategoria
  WHERE v.cpf = '12345678900';

SELECT *
FROM DADOSVEICULO;

-- Demanda B)
-- Consultar proprietário(s) por qualquer parte do nome fornecido pelo usuário;
-- 
SELECT * FROM PROPRIETARIO p
	WHERE p.nome like '%el%';

-- Demanda C) 
-- Mostrar os dados da infração e do veículo que tiveram infrações cadastradas no Detran em um
-- período (ou data) no padrão DE... ATÉ...;
SELECT * FROM INFRACAO i JOIN VEICULO v
		ON i.placa = v.placa
	WHERE i.dataOcorrencia >= '2021-11-09' AND i.dataOcorrencia < '2022-03-22';

-- Demanda D)
-- Pesquisar quantos veículos existem cadastrados por Modelo, inclusive apresentando os modelos
-- cadastrados que não tiverem nenhum veículo cadastrado, se existir tal situação.
SELECT COUNT(m.idModelo),m.nome FROM VEICULO v JOIN MODELO m
		ON v.idModelo = m.idModelo
    group by v.idModelo;

