-- --------- << aula4exer6Evolucao4 >> ---------
-- 
--           SCRIPT APAGA (DDL)
--
-- Data Criacao ......: 27/02/2022
-- Autor(es) .........: Lucas da Cunha Andrade, Victor Eduardo Araujo Ribeiro, Pedro Henrique Carvalho Campos
-- Banco de Dados ....: MySQL 8.0
-- Base de Dados .....: aula4exer6Evolucao4
--
-- Ultimas Alteracoes
--   Victor Eduardo: 09/03/2022 => Alteracao na ordem de exclusao das tabelas, exlcuindo na ordem inversa de criacao
--
--   Pedro Campos: 18/04/2022 => Adição tabelas situa e aplica.
--                            => Mudança na ordem das tabelas.
--                            => Mudança no nome da base de dados
--   
-- PROJETO => 01 Base de Dados
-- 		   => 11 Tabelas
--         => 2 perfis
--         => 4 consultas
--
USE aula4exer6Evolucao4;

DROP TABLE telefone;
DROP TABLE aplica;
DROP TABLE situa;
DROP TABLE INFRACAO;
DROP TABLE TIPO;
DROP TABLE AGENTE;
DROP TABLE VEICULO;
DROP TABLE CATEGORIA;
DROP TABLE MODELO;
DROP TABLE PROPRIETARIO;
DROP TABLE LOCALIZACAO;